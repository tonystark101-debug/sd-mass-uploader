"""Entry point: ``python main.py <command>``."""

import sys

from src.cli.commands import main

if __name__ == "__main__":
    sys.exit(main())
