"""The only place that launches OS programs, restricted to read-only inventory tools."""

from __future__ import annotations

import base64
import re
import subprocess
from dataclasses import dataclass
from pathlib import PurePath
from typing import Protocol

from src.core.exceptions import DeviceDetectionError, ReadOnlyViolation

ALLOWED_PROGRAMS = frozenset({"powershell", "lsblk", "lsusb", "findmnt"})

# Backstop for inline PowerShell. The scripts here only read, and this keeps it that way.
_FORBIDDEN_POWERSHELL = re.compile(
    r"\b(Format-|Clear-Disk|Initialize-Disk|Set-Disk|Set-Partition|Set-Volume|Remove-|"
    r"New-Partition|Resize-Partition|Repair-Volume|Add-PartitionAccessPath|"
    r"Mount-|Dismount-|diskpart|chkdsk|Move-Item|Set-Content|Out-File|Invoke-Expression)",
    re.IGNORECASE,
)


@dataclass
class CommandResult:
    returncode: int
    stdout: str
    stderr: str


class CommandRunner(Protocol):
    def run(self, argv: list[str], timeout: float = 60) -> CommandResult: ...


def assert_read_only(argv: list[str]) -> None:
    """Refuse anything outside the allowlist before a process can start."""
    if not argv:
        raise ReadOnlyViolation("Empty command")
    program = PurePath(argv[0]).stem.lower()
    if program not in ALLOWED_PROGRAMS:
        raise ReadOnlyViolation(f"Command is not on the read-only allowlist: {argv[0]}")


class SubprocessRunner:
    """Runs argument lists (never a shell), with a timeout and captured stderr."""

    def run(self, argv: list[str], timeout: float = 60) -> CommandResult:
        assert_read_only(argv)
        try:
            done = subprocess.run(
                argv,
                capture_output=True,
                timeout=timeout,
                check=False,
                stdin=subprocess.DEVNULL,
            )
        except FileNotFoundError as exc:
            raise DeviceDetectionError(f"Program not found: {argv[0]}") from exc
        except subprocess.TimeoutExpired as exc:
            raise DeviceDetectionError(f"{argv[0]} timed out after {timeout}s") from exc
        except OSError as exc:
            raise DeviceDetectionError(f"Could not run {argv[0]}: {exc}") from exc
        return CommandResult(
            done.returncode,
            done.stdout.decode("utf-8", errors="replace"),
            done.stderr.decode("utf-8", errors="replace"),
        )


def run_powershell(runner: CommandRunner, script: str, timeout: float = 60) -> CommandResult:
    """Run a read-only script. It is base64-encoded so no quoting can alter it."""
    match = _FORBIDDEN_POWERSHELL.search(script)
    if match:
        raise ReadOnlyViolation(f"Script contains forbidden command: {match.group(0)}")
    encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    argv = ["powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded]
    return runner.run(argv, timeout=timeout)
