"""Builds the object graph once, so commands stay short."""

from __future__ import annotations

from dataclasses import dataclass

from src.core.settings import Settings, load_settings
from src.database.db import Database
from src.database.repositories import InventoryRepository, ScanRepository, SessionRepository
from src.device_manager.base import PlatformAdapter
from src.device_manager.detector import create_adapter
from src.inventory.inventory_service import ScanService
from src.reporting.report_generator import ReportGenerator
from src.uploader.finalize import SessionFinalizer
from src.uploader.gcs_client import GcsObjectStore, ObjectStore


@dataclass
class App:
    settings: Settings
    db: Database
    inventory: InventoryRepository
    scans: ScanRepository
    sessions: SessionRepository

    @classmethod
    def open(cls, config_path: str) -> App:
        settings = load_settings(config_path)
        db = Database(settings.resolve(settings.database.path))
        return cls(settings, db, InventoryRepository(db), ScanRepository(db),
                   SessionRepository(db))

    def adapter(self) -> PlatformAdapter:
        return create_adapter(self.settings.device_detection)

    def scan_service(self) -> ScanService:
        return ScanService(self.scans, self.settings.file_scanning)

    def store(self) -> ObjectStore:
        self.settings.require_gcs()
        return GcsObjectStore(self.settings.google_cloud, self.settings.upload)

    def reports(self) -> ReportGenerator:
        reporting = self.settings.reporting
        directory = self.settings.resolve(reporting.directory)
        return ReportGenerator(self.sessions, self.scans, directory, reporting.json, reporting.csv)

    def finalizer(self, store: ObjectStore) -> SessionFinalizer:
        return SessionFinalizer(self.sessions, self.scans, store, self.reports())
