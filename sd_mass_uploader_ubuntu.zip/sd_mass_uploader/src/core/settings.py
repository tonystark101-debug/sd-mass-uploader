"""Load and validate config.yaml. Unknown keys are errors so typos cannot be ignored."""

from __future__ import annotations

from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any

import yaml

from src.core.enums import DuplicatePolicy
from src.core.exceptions import ConfigurationError

GCS_CHUNK_MULTIPLE = 256 * 1024
_PLACEHOLDER = "REPLACE_WITH_"


@dataclass
class ApplicationSettings:
    name: str = "SD Mass Uploader"
    environment: str = "development"
    log_level: str = "INFO"


@dataclass
class DeviceDetectionSettings:
    scan_interval_seconds: int = 5
    detect_usb_topology: bool = True
    include_unmounted_storage: bool = True
    inventory_stale_seconds: int = 300


@dataclass
class FileScanningSettings:
    follow_symlinks: bool = False
    calculate_sha256: bool = False
    ignore_hidden_files: bool = False
    exclude_dirs: list[str] = field(
        default_factory=lambda: ["System Volume Information", "$RECYCLE.BIN"]
    )


@dataclass
class GoogleCloudSettings:
    project_id: str = ""
    bucket_name: str = ""
    root_prefix: str = "uploads"


@dataclass
class UploadSettings:
    max_workers: int = 4
    chunk_size_mib: float = 64
    max_retries: int = 5
    backoff_initial_seconds: float = 2
    backoff_max_seconds: float = 60
    request_timeout_seconds: float = 120
    duplicate_policy: DuplicatePolicy = DuplicatePolicy.FAIL
    overwrite_existing: bool = False
    verify_after_upload: bool = True
    object_metadata_fields: list[str] = field(
        default_factory=lambda: ["project_name", "activity_name", "recording_date"]
    )

    @property
    def chunk_size_bytes(self) -> int:
        return int(self.chunk_size_mib * 1024 * 1024)



@dataclass
class MetadataSettings:
    require_operator_name: bool = True
    require_place_of_recording: bool = True


@dataclass
class DatabaseSettings:
    path: str = "data/database/uploader.db"


@dataclass
class ReportingSettings:
    directory: str = "data/reports"
    json: bool = True
    csv: bool = True


@dataclass
class LoggingSettings:
    directory: str = "logs"
    max_bytes: int = 10_485_760
    backup_count: int = 5


@dataclass
class Settings:
    application: ApplicationSettings = field(default_factory=ApplicationSettings)
    device_detection: DeviceDetectionSettings = field(default_factory=DeviceDetectionSettings)
    file_scanning: FileScanningSettings = field(default_factory=FileScanningSettings)
    google_cloud: GoogleCloudSettings = field(default_factory=GoogleCloudSettings)
    upload: UploadSettings = field(default_factory=UploadSettings)
    metadata: MetadataSettings = field(default_factory=MetadataSettings)
    database: DatabaseSettings = field(default_factory=DatabaseSettings)
    reporting: ReportingSettings = field(default_factory=ReportingSettings)
    logging: LoggingSettings = field(default_factory=LoggingSettings)
    base_dir: Path = field(default_factory=Path.cwd)

    def resolve(self, relative: str) -> Path:
        """Resolve a configured path against the config file's folder, not the shell's cwd."""
        path = Path(relative)
        return path if path.is_absolute() else self.base_dir / path

    def require_gcs(self) -> None:
        """Fail early, with a useful message, if the bucket settings are still placeholders."""
        gcs = self.google_cloud
        for name, value in (("project_id", gcs.project_id), ("bucket_name", gcs.bucket_name)):
            if not value or value.startswith(_PLACEHOLDER):
                raise ConfigurationError(f"Set google_cloud.{name} in config.yaml")


def _build(cls: type, values: dict[str, Any], where: str) -> Any:
    known = {f.name for f in fields(cls)} - {"base_dir"}
    unknown = set(values) - known
    if unknown:
        raise ConfigurationError(f"Unknown setting(s) in {where}: {sorted(unknown)}")
    kwargs: dict[str, Any] = {}
    defaults = cls()
    for name, value in values.items():
        default = getattr(defaults, name)
        if is_dataclass(default):
            if not isinstance(value, dict):
                raise ConfigurationError(f"{where}.{name} must be a mapping")
            kwargs[name] = _build(type(default), value, f"{where}.{name}")
        else:
            kwargs[name] = _coerce(value, default, f"{where}.{name}")
    return cls(**kwargs)


def _coerce(value: Any, default: Any, where: str) -> Any:
    if isinstance(default, DuplicatePolicy):
        try:
            return DuplicatePolicy(value)
        except ValueError as exc:
            choices = [p.value for p in DuplicatePolicy]
            raise ConfigurationError(f"{where} must be one of {choices}") from exc
    if isinstance(default, bool):
        if not isinstance(value, bool):
            raise ConfigurationError(f"{where} must be true or false")
        return value
    if isinstance(default, int | float):
        if isinstance(value, bool) or not isinstance(value, int | float):
            raise ConfigurationError(f"{where} must be a number")
        return value
    if isinstance(default, list) and not isinstance(value, list):
        raise ConfigurationError(f"{where} must be a list")
    if isinstance(default, str) and not isinstance(value, str):
        raise ConfigurationError(f"{where} must be text")
    return value


def validate(settings: Settings) -> None:
    upload = settings.upload
    if upload.max_workers < 1:
        raise ConfigurationError("upload.max_workers must be at least 1")
    if upload.max_retries < 0:
        raise ConfigurationError("upload.max_retries cannot be negative")
    if upload.chunk_size_bytes <= 0 or upload.chunk_size_bytes % GCS_CHUNK_MULTIPLE:
        raise ConfigurationError("upload.chunk_size_mib must be a multiple of 256 KiB")
    if upload.backoff_initial_seconds <= 0 or upload.backoff_max_seconds <= 0:
        raise ConfigurationError("upload backoff values must be positive")
    if settings.device_detection.scan_interval_seconds < 1:
        raise ConfigurationError("device_detection.scan_interval_seconds must be at least 1")
    if settings.application.log_level.upper() not in {
        "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL",
    }:
        raise ConfigurationError("application.log_level is not a valid level")


def load_settings(path: str | Path = "config.yaml") -> Settings:
    config_path = Path(path).resolve()
    try:
        with open(config_path, encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
    except FileNotFoundError as exc:
        raise ConfigurationError(f"Config file not found: {config_path}") from exc
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"Config file is not valid YAML: {exc}") from exc
    if not isinstance(data, dict):
        raise ConfigurationError("Config file must contain a mapping")
    settings: Settings = _build(Settings, data, "config")
    settings.base_dir = config_path.parent
    validate(settings)
    return settings
