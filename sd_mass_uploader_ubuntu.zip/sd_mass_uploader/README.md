# SD Mass Uploader

Reads many SD cards at once through USB readers and uploads them to Google Cloud Storage. Every
file is checked against the bucket before it counts as done. It runs on Windows and Ubuntu.

Source cards are read-only: this program never writes to, formats, repairs, moves or deletes
anything on them.

## Setup

Windows:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\windows\setup.ps1
.\.venv\Scripts\Activate.ps1
```

Ubuntu:

```bash
bash scripts/ubuntu/setup.sh
source .venv/bin/activate
```

Then:

1. Set `google_cloud.project_id` and `google_cloud.bucket_name` in `config.yaml`.
2. Sign in with Application Default Credentials:

   ```bash
   gcloud auth application-default login
   ```

   Never put keys in `config.yaml`. In production, use a service account outside this folder.
3. Confirm the bucket works. This uploads one small generated file to a test prefix and checks
   it. The file stays in the bucket.

   ```bash
   python main.py gcs-test
   ```

The identity needs `storage.objects.create` and `storage.objects.get` on the bucket
(`roles/storage.objectUser` covers both, or a narrower custom role). Keep the bucket private.

## Everyday workflow

1. Connect the powered hubs, readers, cards and Ethernet.
2. Check the hardware. Look for readers below 5 Gbps and anything not `ACTIVE`.

   ```bash
   python main.py check
   ```

3. Review what is on the cards.

   ```bash
   python main.py scan --files
   ```

4. Upload. It asks for the session details, shows the destination and totals, and starts only
   after you type `yes`.

   ```bash
   python main.py upload
   ```

5. If it did not end in `SUCCESS`, follow the command it prints. To re-check an old session:

   ```bash
   python main.py verify --session SESSION_ID
   ```

To skip the prompts, keep the answers in a file (see `session.example.json`):

```bash
python main.py upload --metadata-file session.json
```

## Commands

| Command | What it does |
| --- | --- |
| `check` | Refresh the hardware inventory. `--all` shows internal disks, `--json` prints raw data |
| `scan` | List volumes. `--files` adds a full file scan, `--sha256` also hashes, `--path` scans a folder |
| `status` | Show the last saved state and how old it is. It does not query devices |
| `monitor` | Watch for readers and cards being added or removed |
| `upload` | Metadata, selection, preview, confirmation, upload. `--workers N` overrides concurrency |
| `retry` | Reconcile with GCS, then resume or retry a session (latest by default) |
| `verify` | Recheck objects in GCS. `--deep` also re-reads the source cards |
| `report` | Rewrite the JSON, CSV and error log for a session |
| `stop` | Ask a running upload to stop after the files in progress |
| `gcs-test` | Upload and check one small test file |
| `benchmark` | Measure simultaneous read speed from all cards |

Reports are written to `data/reports/SESSION_ID/`. Logs are in `logs/`.

## How to read the results

### Device status

| Status | Meaning |
| --- | --- |
| `ACTIVE` | The card is detected and readable |
| `EMPTY_READER` | The OS confirms no medium. Never guessed from a missing volume |
| `READER_PRESENT_SLOT_UNKNOWN` | The reader is visible but says nothing about its slot |
| `UNMOUNTED_STORAGE` | A card is present with no usable mount. Mount it yourself |
| `INACCESSIBLE` | Access was denied |
| `ERROR` | A read or detection error, or a card that stopped responding |
| `DISCONNECTED` | Seen in the previous inventory, absent now |
| `UNKNOWN` | Not enough evidence to say |

### File status

| Status | Meaning | What to do |
| --- | --- | --- |
| `VERIFIED` | GCS has the same size and CRC32C | Nothing |
| `UPLOADED_UNVERIFIED` | Uploaded with verification turned off | Run `verify` |
| `FAILED` | Network retries ran out, or the card went away | Run `retry` |
| `FAILED_PERMANENT` | The file changed or vanished after the scan | Check the source, then start a new session |
| `CONFLICT` | A different object is at that path, or a checksum did not match | Investigate, then `retry --include-conflicts` |
| `UNCERTAIN` | Interrupted, and the card is not here to prove the object matches | Reattach the card, run `retry` |

A session is `SUCCESS` only if every file is `VERIFIED` and the scan found no unreadable files.

## Behavior worth knowing

- **Cards are tracked by volume serial, not drive letter.** After a replug, the card is found
  again wherever it mounted. A different card in the same slot is refused.
- **Internal disks can never be selected.** Only volumes proven to be on a USB, SD or MMC bus are
  offered.
- **Some cards need confirmation.** A device that does not call itself a card reader could be a
  USB drive, and a cloned card shares a serial with another. These are left out of `all` and
  `--yes`, and are uploaded only if you choose them by number or with `--cards`.
- **Nothing is overwritten silently.** Uploads use a GCS generation precondition. If an object
  exists with identical content it is accepted. If different, the file becomes `CONFLICT`, or
  sits beside it under `duplicate_policy: new_path`. Overwriting needs
  `upload.overwrite_existing: true` plus `--allow-overwrite --overwrite-reason "..."`.
- **Stopping.** `stop` or one Ctrl+C finishes the files in progress, so it can take a while on a
  large file. A second Ctrl+C abandons them after the current read, and they stay queued.
- **Crashes.** After a crash, `retry` is refused for up to a minute, in case the old process is
  still running. It then checks GCS first, so finished files are not sent again.
- **Network loss.** Each file retries with backoff up to `max_retries`, then becomes `FAILED`. A
  long outage therefore ends the run; `retry` picks it up. Authentication and permission errors
  stop the session at once.
- **Personal data.** `operator_name` and `place_of_recording` are not copied to object metadata
  unless added to `upload.object_metadata_fields`. They do appear in the manifest stored beside
  the files.

## Tuning

Start from `benchmark`, which shows what the cards, hubs and controllers can deliver together.
Then compare real uploads with `--workers 4`, `8` and `12`, using the MB/s in each report. Keep
the best *stable* result, not the fastest single run.

Peak memory is about `max_workers × chunk_size_mib`, so 12 workers at 64 MiB can hold 768 MiB.

## Maintenance

Back up `data/database/uploader.db` and `data/reports/` while nothing is uploading. Agree bucket
versioning, retention, lifecycle and data residency with the data owner before production use.
Test objects from `gcs-test` and benchmarks are not cleaned up automatically.

## Development

```bash
python -m pytest
python -m ruff check .
```

The integration tests run the real Google client against `tests/integration/fake_gcs_server.py`,
a local server that speaks the storage protocol. Passing them shows this code drives the client
correctly. It does not show how real GCS, IAM or your network behave.

Physical testing is separate: see [docs/HARDWARE_ACCEPTANCE.md](docs/HARDWARE_ACCEPTANCE.md).

## Known limitations

- **Windows speed cap:** SuperSpeedPlus shows as 10 Gbps, the lowest rate in that class, because
  the Windows query does not report the exact rate.
- **Hubs on Ubuntu:** a USB 3 hub appears twice, once per bus, so hub counts can be double.
- **`monitor` polls.** On Windows one pass takes about 10 seconds, so it is not instant.
- **Access times:** reading can update a file's last-access time where the filesystem records it.
  Contents and modified times are unchanged. On Ubuntu the program avoids this when it can.
- **CPU and RAM** are not recorded by `benchmark`. Read them from Task Manager or `top`.
- **Resumable sessions** are not kept across restarts. A large file interrupted by a crash starts
  again from zero, and an unfinished GCS session simply expires.
